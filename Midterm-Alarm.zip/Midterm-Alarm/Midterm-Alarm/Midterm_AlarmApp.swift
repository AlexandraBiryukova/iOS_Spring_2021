//
//  Midterm_AlarmApp.swift
//  Midterm-Alarm
//
//  Created by Alexandra Biryukova on 3/18/21.
//

import SwiftUI

@main
struct Midterm_AlarmApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
